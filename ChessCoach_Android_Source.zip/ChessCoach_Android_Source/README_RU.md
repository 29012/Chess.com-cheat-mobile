# ChessCoach Android — исходный проект

## Что уже подготовлено
- Android Studio / Gradle-проект.
- GitHub Actions workflow, который собирает debug APK.
- WebView открывает Chess.com внутри самого APK.
- Исходные файлы ChessCoach сохранены без изменений в `app/src/main/assets/chesscoach/`.

## Важное ограничение текущей версии
Это **заготовка Android-хоста**, а не готовый перенос расширения. Исходное расширение написано под Chrome Manifest V3 и использует `chrome.runtime`, `chrome.storage`, service worker и content scripts. Android WebView этих API не предоставляет. Поэтому меню, настройки, движок и распознавание ещё не подключены к WebView; простое копирование файлов не делает расширение APK.

Также эта версия открывает Chess.com во встроенном WebView, а не поверх отдельно установленного официального приложения Chess.com. Для внешнего overlay потребуется отдельный Android overlay service и захват экрана через MediaProjection с явным согласием пользователя.

## Сборка через GitHub
1. Создай пустой репозиторий на GitHub.
2. Загрузи в него всё содержимое этой папки (файлы и скрытую папку `.github` тоже).
3. Открой вкладку **Actions**.
4. Запусти **Build ChessCoach Android APK** через **Run workflow** или сделай push в `main`.
5. Скачай артефакт `ChessCoach-debug-apk` из завершённого workflow.

## Что требуется для полного переноса
1. Android-реализация `chrome.storage.local` на базе SharedPreferences/DataStore.
2. Замена `chrome.runtime.sendMessage` на Android-JS bridge и перенос обработчиков из background service worker.
3. Инъекция скриптов после загрузки страницы через WebViewClient с корректной обработкой SPA-навигации.
4. Адаптация селекторов/состояния доски под актуальный DOM Chess.com.
5. Отдельное тестирование Stockfish Worker/WASM на целевых версиях Android WebView.
6. Проверка всех экранов меню и настроек на телефоне.

Оригинальные JS/CSS-файлы в `assets/chesscoach` намеренно не переписаны в этом стартовом проекте.
